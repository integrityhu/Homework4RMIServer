#!/bin/bash
rmiregistry -J-Djava.rmi.server.codebase="http://localhost/rmi/"
