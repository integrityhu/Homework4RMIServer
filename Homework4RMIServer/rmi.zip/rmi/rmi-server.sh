java -cp .:./compute.jar -Djava.rmi.server.codebase=http://localhost/rmi/compute.jar -Djava.rmi.server.hostname=localhost -Djava.security.policy=server.policy engine.ComputeEngine
