/**
 * 
 */
package compute;

/**
 * @author pzoli
 *
 */
public interface Task<T> {
    T execute();
}
