#!/bin/bash
rmiregistry -J-Djava.rmi.server.codebase="http://localdev-wlan-home/rmi/"
