java -cp .:./compute.jar -Djava.rmi.server.codebase=http://localdev-wlan-home/rmi/compute.jar -Djava.rmi.server.hostname=localdev-wlan-home -Djava.security.policy=server.policy engine.ComputeEngine
