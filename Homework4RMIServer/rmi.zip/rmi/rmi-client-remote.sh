#!/bin/bash
java -cp .:./compute.jar -Djava.rmi.server.codebase=http://localdev-wlan-home/rmi/ -Djava.security.policy=client.policy client.ComputePi localdev-wlan-home 45
