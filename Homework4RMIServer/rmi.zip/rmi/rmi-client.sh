#!/bin/bash
java -cp .:./compute.jar -Djava.rmi.server.codebase=http://localhost/rmi/ -Djava.security.policy=client.policy client.ComputePi localhost 45
